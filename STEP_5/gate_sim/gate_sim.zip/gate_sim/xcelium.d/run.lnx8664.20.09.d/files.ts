1774157891 /home/linux/ieng6/ECE260B_WI26_A00/pmekkoth/ece_260b_project-main/STEP_5/gate_sim/netlist/fullchip.pnr.v
1774157647 /home/linux/ieng6/ECE260B_WI26_A00/pmekkoth/ece_260b_project-main/STEP_5/gate_sim/netlist/tcbn65gplus.v
1774157647 /home/linux/ieng6/ECE260B_WI26_A00/pmekkoth/ece_260b_project-main/STEP_5/gate_sim/netlist/seqgen.v
1774157647 /home/linux/ieng6/ECE260B_WI26_A00/pmekkoth/ece_260b_project-main/STEP_5/gate_sim/netlist/gtech.v
1774160579 /home/linux/ieng6/ECE260B_WI26_A00/pmekkoth/ece_260b_project-main/STEP_5/gate_sim/netlist/fullchip_tb.v
