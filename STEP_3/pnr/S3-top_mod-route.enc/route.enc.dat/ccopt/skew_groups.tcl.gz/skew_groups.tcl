## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_10_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_11_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_12_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_13_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_14_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_15_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_16_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_17_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_18_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_19_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_20_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_21_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_22_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_23_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_7_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_8_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_9_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_10_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_11_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_12_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_13_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_14_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_15_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_16_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_17_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_18_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_19_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_20_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_21_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_22_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_23_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_7_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_8_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_9_/CP 0.2
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_10_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_11_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_12_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_13_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_14_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_15_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_16_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_17_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_18_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_19_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_20_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_21_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_22_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_23_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_7_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_8_/CP 0.2
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_9_/CP 0.2
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_10_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_11_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_12_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_13_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_14_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_15_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_16_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_17_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_18_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_19_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_20_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_21_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_22_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_23_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_7_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_8_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin sfp_instance/fifo_inst_int/out_reg_9_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_10_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_11_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_12_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_13_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_14_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_15_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_16_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_17_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_18_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_19_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_20_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_21_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_22_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_23_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_7_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_8_/CP 0.2
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin sfp_instance/fifo_inst_int/out_reg_9_/CP 0.2
# Skew Group: clk/CON
create_ccopt_skew_group -name clk/CON -from_clock clk -from_constraint_modes {CON} -from_delay_corners {WC BC} -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default